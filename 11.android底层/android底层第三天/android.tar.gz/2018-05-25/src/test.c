#include <stdio.h>

int main(int argc, const char *argv[])
{
	printf("hello world \n");
	return 0;
}
