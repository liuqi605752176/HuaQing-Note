#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<string.h>

#define LIST 1
typedef struct ftp_data
{
	int type;
	char data[128];
}my_ftp_data_t;

void user_list(my_ftp_data_t info,int sockfd)
{
	int i;
	int count = 0;
	info.type = LIST;
	send(sockfd,&info,sizeof(info),0);
	recv(sockfd,&info,sizeof(info),0);
//	printf("%s\n",info.data);
	
	for(i = 0;i < strlen(info.data);i ++)
	{
		printf("%c",info.data[i]);

		if(info.data[i] == ' ')
		{
			count ++;
			if(count % 2 == 0)
				printf("\n");
		}
	}
	printf("\n");

}

int main(int argc, const char *argv[])
{
	int sockfd;

	sockfd = socket(AF_INET,SOCK_STREAM,0);

	struct sockaddr_in seraddr;
	memset(&seraddr,0,sizeof(seraddr));
	seraddr.sin_family = AF_INET;
	seraddr.sin_port = htons(atoi(argv[1]));
	seraddr.sin_addr.s_addr = inet_addr("172.25.1.194");

	if(connect(sockfd,(struct sockaddr *)&seraddr,sizeof(seraddr)) == -1)
	{
		perror("connect");
		return -1;
	}
	
	char buf[10];
	int choose;

	my_ftp_data_t info;
	while(1)
	{
		printf("**********1. list **********\n");
		printf("**********2. down **********\n");
		
		fgets(buf,sizeof(buf),stdin);
		choose = buf[0] - '0';

		switch(choose)
		{
		case 1:
			user_list(info,sockfd);
			break;
		}
	}
	return 0;
}
