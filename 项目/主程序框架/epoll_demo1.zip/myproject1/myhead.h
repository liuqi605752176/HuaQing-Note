#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/shm.h>
#include <sys/socket.h>
#include <errno.h>
#include <sys/epoll.h>
#include <time.h>
#include <sqlite3.h>


#define LED_REQUEST 'L'
#define TEM_REQUEST 'T'
#define RGS_REQUEST 'R'
#define LOG_REQUEST 'G'
#define OUT_REQUEST 'O' 

#define LED_REQ_MSG 100
#define TEM_REQ_MSG 200

#define LED_SUCCESS 1
#define LED_FAILURE 2
#define TEM_SUCCESS 3
#define TEM_FAILURE 4
#define RGS_SUCCESS 5
#define RGS_FAILURE 6
#define LOG_SUCCESS 7
#define LOG_FAILURE 8
#define LOG_ARLOG   9
#define OUT_SUCCESS 11
#define OUT_FAILURE 12


char *s_gets(char *st,int n);
typedef struct st1
{
	int type;
	char name[128];
	char data[128];
}tcp_t; /* TCP */


typedef struct st2
{
	long type;
	char buf[64];
}msg_t; /* MSG */

typedef struct st3
{
	char tep[6];
}shm_t;  /* SHM */






