#include "myhead.h"

static int islogin = 0;

int go_register(int sockfd,tcp_t *TCP)
{
	if(islogin == 1)
	{
		fprintf(stderr,"您已登录！\n");
		return 9;
	}
	int ret;
	bzero(TCP,sizeof(tcp_t));
	TCP->type = RGS_REQUEST;
	printf("请设置帐号(以回车结束，以空行取消):\n");
	s_gets(TCP->name,sizeof(TCP->name));
	if(TCP->name[0] == '\0' || TCP->name[0] == EOF)
	{
		printf("您已取消注册!\n");
		return 10;
	}
	printf("请设置密码(以回车结束，以空行取消):\n");
	s_gets(TCP->data,sizeof(TCP->data));
	if(TCP->data[0] == '\0' || TCP->data[0] == EOF)
	{
		printf("您已取消注册!\n");
		return 10;
	}
	ret = send(sockfd,TCP,sizeof(tcp_t),0);
	if(ret < 0)
	{
		perror("send(go_register)");
		return -287;
	}
	bzero(TCP,sizeof(tcp_t));
	ret = recv(sockfd,TCP,sizeof(tcp_t),0);
	if(ret < 0)
	{
		perror("recv(go_register)");
		return -4;
	}
	switch(TCP->type)
	{
	case RGS_SUCCESS:printf("注册成功！\n");break;
	case RGS_FAILURE:printf("注册失败！帐号已存在！\n");break;
	default:fprintf(stderr,"未知结果！\n");
	}
	return 0;
}

int go_login(int sockfd,tcp_t *TCP)
{
	if(islogin == 1)
	{
		fprintf(stderr,"您已登录！\n");
		return 9;
	}
	int ret;
	bzero(TCP,sizeof(tcp_t));
	TCP->type = LOG_REQUEST;
	printf("请输入帐号(以回车结束，以空行取消):\n");
	s_gets(TCP->name,sizeof(TCP->name));
	if(TCP->name[0] == '\0' || TCP->name[0] == EOF)
	{
		printf("您已取消登录!\n");
		return 11;
	}
	printf("请输入密码(以回车结束，以空行取消):\n");
	s_gets(TCP->data,sizeof(TCP->data));
	if(TCP->data[0] == '\0' || TCP->data[0] == EOF)
	{
		printf("您已取消登录!\n");
		return 11;
	}
	ret = send(sockfd,TCP,sizeof(tcp_t),0);
	if(ret < 0)
	{
		perror("send(go_login)");
		return -286;
	}
	bzero(TCP,sizeof(tcp_t));
	ret = recv(sockfd,TCP,sizeof(tcp_t),0);
	if(ret < 0)
	{
		perror("recv(go_login)");
		return -1234;
	}
	switch(TCP->type)
	{
	case LOG_SUCCESS:printf("登录成功！\n");islogin=1;break;
	case LOG_FAILURE:printf("登录失败！帐号或密码错误！\n");break;
	case LOG_ARLOG:printf("登录失败！该帐号已经登录！\n");break;
	default:fprintf(stderr,"未知结果！\n");
	}
	return 0;	
}

int go_logout(int sockfd,tcp_t *TCP)
{
	if(islogin == 0)
	{
		fprintf(stderr,"您尚未登录！\n");
		return -1000;
	}
	int ret;
	TCP->type = OUT_REQUEST;
	ret = send(sockfd,TCP,sizeof(tcp_t),0);
	if(ret < 0)
	{
		perror("send(go_logout)");
		return -285;
	}
	bzero(TCP,sizeof(tcp_t));
	ret = recv(sockfd,TCP,sizeof(tcp_t),0);
	if(ret < 0)
	{
		perror("recv(go_logout)");
		return -1235;
	}
	switch(TCP->type)
	{
	case OUT_SUCCESS:printf("注销成功！\n");islogin=0;break;
	case OUT_FAILURE:printf("注销失败！\n");break;
	default:fprintf(stderr,"未知结果！\n");
	}

	return 0;
}

int go_led(int sockfd,tcp_t *TCP)
{
	if(islogin == 0)
	{
		fprintf(stderr,"您尚未登录！\n");
		return -1000;
	}
	int ret;
	TCP->type = LED_REQUEST;	
	ret = send(sockfd,TCP,sizeof(tcp_t),0);	
	if(ret < 0)
	{
		perror("send(go_led)");
		return -288;
	}
	bzero(TCP,sizeof(tcp_t));
	ret = recv(sockfd,TCP,sizeof(tcp_t),0);
	if(ret < 0)
	{
		perror("recv(go_led)");
		return -4;
	}
	switch(TCP->type)
	{
	case LED_SUCCESS:printf("点灯成功！\n");break;
	case LED_FAILURE:printf("点灯失败！\n");break;
	default:fprintf(stderr,"未知结果！\n");
	}
	return 0;

}

int go_temperature(int sockfd,tcp_t *TCP)
{
	if(islogin == 0)
	{
		fprintf(stderr,"您尚未登录！\n");
		return -1000;
	}
	int ret;
	TCP->type = TEM_REQUEST;
	ret = send(sockfd,TCP,sizeof(tcp_t),0);	
	if(ret < 0)
	{
		perror("send(go_temperature)");
		return -289;
	}
	
	bzero(TCP,sizeof(tcp_t));
	ret = recv(sockfd,TCP,sizeof(tcp_t),0);
	if(ret < 0)
	{
		perror("recv(go_temperature)");
		return -312;
	}
	switch(TCP->type)
	{
	case TEM_SUCCESS:printf("当前温度：%s\n",TCP->data);break;
	case TEM_FAILURE:printf("查询温度失败！\n");break;
	default:fprintf(stderr,"未知结果！\n");
	}
	return 0;

}

int main(int argc, const char *argv[])
{
	int sockfd,ret,temp;
	tcp_t TCP;
	if(argc < 3)
	{
		fprintf(stderr,"请输入IP和端口号！\n");
		return -999;
	}

	sockfd = socket(AF_INET,SOCK_STREAM,0);
	if(sockfd < 0)
	{
		perror("socket");
		return -1;
	}
	struct sockaddr_in peeraddr;
	peeraddr.sin_family = AF_INET;
	peeraddr.sin_port = htons(atoi(argv[2]));
	peeraddr.sin_addr.s_addr = inet_addr(argv[1]);
	socklen_t len = sizeof(peeraddr);

	ret = connect(sockfd,(struct sockaddr *)&peeraddr,len);
	if(ret < 0)
	{
		perror("connect");
		return -2;
	}

	while(1)
	{
		printf("请选择您想要的功能：\n");
		printf("(%c)注册\t(%c)登录\t(%c)点灯\t(%c)查看温度\t(%c)注销\n",
				RGS_REQUEST,LOG_REQUEST,LED_REQUEST,TEM_REQUEST,OUT_REQUEST);
		temp = getchar();
		while(getchar()!='\n');
		switch(temp)
		{
		case RGS_REQUEST:
			go_register(sockfd,&TCP);
			break;
		case LOG_REQUEST:
			go_login(sockfd,&TCP);
			break;
		case LED_REQUEST:
			go_led(sockfd,&TCP);
			break;
		case TEM_REQUEST:
			go_temperature(sockfd,&TCP);
			break;
		case OUT_REQUEST:
			go_logout(sockfd,&TCP);
			break;
		default:
			printf("您的输入有误，请重新输入！\n");
			usleep(500000);
			continue;
		}
	}
	return 0;
}

char *s_gets(char *st,int n)
{
	char *find;
	char *s;
	if(s = fgets(st,n,stdin))
	{
		find = strchr(st,'\n');
		if(find)
			*find = '\0';
		else
			while(getchar()!='\n');
	}
	return s;
}
