#include "myhead.h"
int callback(void *arg,int count,char **colval,char **colname)
{
	strcpy((char *)arg,colval[0]);
	return 0;
}
int do_register(int confd,tcp_t *TCP,sqlite3 *db)
{
	int ret;
	char sql_find[128];
	char sql_ins[128];
	char buf[128]={0};
	char *errmsg;
	sprintf(sql_find,"select id from user where id =='%s'",TCP->name);
	sprintf(sql_ins,"insert into user values('%s','%s',0)",TCP->name,TCP->data);
	if(0 != sqlite3_exec(db,sql_find,callback,buf,&errmsg))
	{
		fprintf(stderr,"do_register(exec find)\n");
		sqlite3_free(errmsg);
		return -700;
	}
	if(buf[0]!='\0')    //说明用户已存在,注册失败
	{
		TCP->type = RGS_FAILURE;
		ret = send(confd,TCP,sizeof(tcp_t),0);
		if(ret < 0)
		{
			perror("send(do_register)");
			return -5;
		}
	}
	else
	{
		if(0 != sqlite3_exec(db,sql_ins,NULL,NULL,&errmsg))
		{
			fprintf(stderr,"do_register(exec insert)\n");
			return -701;
		}
		TCP->type = RGS_SUCCESS;
		ret = send(confd,TCP,sizeof(tcp_t),0);
		if(ret < 0)
		{
			perror("send(do_register)");
			return -5;
		}
	}
	return 0;
}

int do_login(int confd,tcp_t *TCP,sqlite3 *db)
{
	int ret;
	char *errmsg;
	char sql_find[128];
	char sql_islogin[128];
	char sql_change[128];
	char buf[128]={0};
	sprintf(sql_find,"select id from user where id=='%s' and passwd=='%s'",TCP->name,TCP->data);
	sprintf(sql_islogin,"select id from user where id=='%s' and passwd=='%s' and islogin==0",TCP->name,TCP->data);
	sprintf(sql_change,"update user set islogin=1 where id=='%s'",TCP->name);
	if(0 != sqlite3_exec(db,sql_find,callback,buf,&errmsg))
	{
		fprintf(stderr,"do_login(exec find)");
		return -24;
	}
	if(buf[0]=='\0')  //帐号密码不匹配
	{
		TCP->type = LOG_FAILURE;
		ret = send(confd,TCP,sizeof(tcp_t),0);
		if(ret < 0)
		{
			perror("send(do_login)");
			return -7;
		}
		return 0;
	}

	bzero(buf,sizeof(buf));
	if(0 != sqlite3_exec(db,sql_islogin,callback,buf,&errmsg))
	{
		fprintf(stderr,"do_login(exec findislogin)");
		return -25;
	}
	if(buf[0]=='\0')  //欲登录的帐号已登录
	{
		TCP->type = LOG_ARLOG;
		ret = send(confd,TCP,sizeof(tcp_t),0);
		if(ret < 0)
		{
			perror("send(do_login)");
			return -7;
		}
		return 0;
	}

	if(0 != sqlite3_exec(db,sql_change,NULL,NULL,&errmsg))
	{
		fprintf(stderr,"do_login(exec change islogin)");
		return -26;
	}
	TCP->type = LOG_SUCCESS;
	ret = send(confd,TCP,sizeof(tcp_t),0);
	if(ret < 0)
	{
		perror("send(do_login)");
		return -7;
	}
	return 0;
}

int do_logout(int confd,tcp_t *TCP,sqlite3 *db)
{
	int ret;
	char sql_logout[128];
	char sql_find[128];
	char buf[128]={0};
	char *errmsg;
	sprintf(sql_find,"select id from user where id=='%s' and islogin==1",TCP->name);
	sprintf(sql_logout,"update user set islogin=0 where id=='%s'",TCP->name);
	if(0 != sqlite3_exec(db,sql_find,callback,buf,&errmsg))
	{
		fprintf(stderr,"do_logout(exec find)");
		return -26;
	}
	if(buf[0]=='\0')     //灵异错误
	{
		TCP->type = OUT_FAILURE;
		ret = send(confd,TCP,sizeof(tcp_t),0);
		if(ret < 0)
		{
			perror("send(do_logout)");
			return -7;
		}
	}
	else
	{
		if(0 != sqlite3_exec(db,sql_logout,NULL,NULL,&errmsg))
		{
			fprintf(stderr,"do_logout(exec find)");
			return -26;
		}
		TCP->type = OUT_SUCCESS;
		ret = send(confd,TCP,sizeof(tcp_t),0);
		if(ret < 0)
		{
			perror("send(do_logout)");
			return -7;
		}
	}
	return 0;
}

int turn_on_led(int confd,int msgid,tcp_t *TCP,msg_t *MSG)
{
	int ret;
	time_t t;
	bzero(TCP->data,sizeof(TCP->data));
	bzero(MSG,sizeof(msg_t));
	MSG->type = LED_REQ_MSG;
	time(&t);
	strcpy(MSG->buf,ctime(&t));
	MSG->buf[strlen(MSG->buf)-1]='\0';
	strcat(MSG->buf," 开了个灯\n");
	size_t len_msg = sizeof(msg_t) - sizeof(long); 
	ret = msgsnd(msgid,MSG,len_msg,0);
	if(ret < 0)
	{
		perror("msgsnd(turn_on_led)");
		TCP->type = LED_FAILURE;
	}
	else
		TCP->type = LED_SUCCESS;
	ret = send(confd,TCP,sizeof(tcp_t),0);
	if(ret < 0)
	{
		perror("send(turn_on_led)");
		return -6;
	}
	return 0;
}
int get_temperature(int confd,tcp_t *TCP,shm_t *SHM)
{
	int ret;
	bzero(TCP->data,sizeof(TCP->data));
	strncpy(TCP->data,SHM->tep,strlen(SHM->tep)+1);
	TCP->type = TEM_SUCCESS;
	ret = send(confd,TCP,sizeof(tcp_t),0);
	if(ret < 0)
	{
		perror("send(get_temperature)");
		return -7;
	}
	return 0;
}


int main(int argc, const char *argv[])
{
	int sockfd,confd,ret,ret_epoll,i;
	int shmid,msgid;
	ssize_t recv_ret;
	char *errmsg;
	key_t key;
	sqlite3 *db;
	ret = sqlite3_open("./user.db",&db);
	if(ret < 0)
	{
		fprintf(stderr,"sqlite3_open");
		return -400;
	}
	char *sql_creat = "create table user(id char[128],passwd char[128],islogin int)";
	ret = sqlite3_exec(db,sql_creat,NULL,NULL,&errmsg);
	if(ret < 0)     //表已创建，直接拿来用
	{
		fprintf(stderr,"%s\n",errmsg);
		sqlite3_free(errmsg);
		//return 0;
	}
	key = ftok("/home/linux/",'u');
	if(key < 0)
	{
		perror("ftok");
		return -257;
	}
	shmid = shmget(key,100,0664|IPC_CREAT); //创建共享内存
	if(shmid < 0)
	{
		perror("shmget");
		return -405;
	}
	shm_t *SHM;
	SHM = shmat(shmid,NULL,0);    //获取映射
	if(SHM == NULL)
	{
		perror("shmat");
		return -324;
	}
	 
	msgid = msgget(key,0664|IPC_CREAT);  //创建消息队列
	if(msgid < 0)
	{
		perror("msgget");
		return -197;
	}

	tcp_t TCP;
	msg_t MSG;

	sockfd = socket(AF_INET,SOCK_STREAM,0);
	if(sockfd < 0)
	{
		perror("socket");
		return -1;
	}
	struct sockaddr_in myaddr,peeraddr;
	myaddr.sin_family = AF_INET;
	myaddr.sin_port = htons(50000);
	myaddr.sin_addr.s_addr = inet_addr("0.0.0.0");
	socklen_t len = sizeof(peeraddr);
	
	int opt = 1;
	setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,&opt,sizeof(opt));

	ret = bind(sockfd,(struct sockaddr *)&myaddr,sizeof(myaddr));	
	if(ret < 0)
	{
		perror("bind");
		return -2;
	}
	ret = listen(sockfd,10);
	if(ret < 0)
	{
		perror("listen");
		return -3;
	}
	int epollfd;
	struct epoll_event myepoll;
	struct epoll_event events[50];
	epollfd = epoll_create(50);
	if(epollfd < 0)
	{
		perror("epoll_create");
		return -690;
	}
	myepoll.events = EPOLLIN;
	myepoll.data.fd = sockfd;
	if(-1 == epoll_ctl(epollfd,EPOLL_CTL_ADD,sockfd,&myepoll))
	{
		perror("epoll_ctl(add sockfd)");
		return -691;
	}
	while(1)
	{
		ret_epoll = epoll_wait(epollfd,events,50,-1);
		if(ret_epoll < 0)
		{
			perror("epoll_wait");
			return -692;
		}
		for(i=0;i<ret_epoll;i++)
		{
			if(events[i].data.fd == sockfd)
			{
				confd = accept(sockfd,(struct sockaddr *)&peeraddr,&len);
				if(confd < 0)
				{
					perror("accept");
					return -4;
				}
				printf("peer:%s,port:%d is connected!\n",inet_ntoa(peeraddr.sin_addr),ntohs(peeraddr.sin_port));
				myepoll.events = EPOLLIN;
				myepoll.data.fd = confd;
				if(-1 == epoll_ctl(epollfd,EPOLL_CTL_ADD,confd,&myepoll))
				{
					perror("epoll_ctl(add confd)");
					return -951;
				}
			}
			else
			{
				bzero(&TCP,sizeof(tcp_t));
				recv_ret = recv(events[i].data.fd,&TCP,sizeof(tcp_t),0);
				if(recv_ret < 0)
				{
					perror("recv");
					return -5;
				}
				else if(recv_ret == 0)
				{
					printf("peer:%d is shutdown!\n",events[i].data.fd);
					if(-1 == epoll_ctl(epollfd,EPOLL_CTL_DEL,events[i].data.fd,NULL))
					{
						perror("epoll_ctl(del confd)");
						return -921;
					}
					close(events[i].data.fd);
				}
				else
				{
					switch(TCP.type)
					{
					case RGS_REQUEST:
						do_register(events[i].data.fd,&TCP,db);
						break;
					case LOG_REQUEST:
						do_login(events[i].data.fd,&TCP,db);
						break;
					case LED_REQUEST:
						turn_on_led(events[i].data.fd,msgid,&TCP,&MSG);
						break;
					case TEM_REQUEST:
						get_temperature(events[i].data.fd,&TCP,SHM);
						break;
					case OUT_REQUEST:
						do_logout(events[i].data.fd,&TCP,db);
						break;
					default:fprintf(stderr,"Wrong Argument!\n");
					}
				}
			}
		}
	}
#if 0
	while(1)
	{
		confd = accept(sockfd,(struct sockaddr *)&peeraddr,&len);
		if(confd < 0)
		{
			perror("accept");
			return -4;
		}
		printf("peer:%s,port:%d is connected!\n",inet_ntoa(peeraddr.sin_addr),ntohs(peeraddr.sin_port));
		while(1)
		{
			bzero(&TCP,sizeof(TCP));
			recv_ret = recv(confd,&TCP,sizeof(tcp_t),0);
			if(recv_ret < 0)
			{
				perror("recv");
				return -5;
			}
			else if(recv_ret == 0)
			{
				printf("peer:%s,port:%d is shutdown!\n",inet_ntoa(peeraddr.sin_addr),ntohs(peeraddr.sin_port));
				break;	
			}
			else
			{
				if(TCP.type == LED_REQUEST)
				{
					bzero(&TCP,sizeof(TCP));
					bzero(&MSG,sizeof(MSG));
					MSG.type = LED_REQ_MSG;
					strcpy(MSG.buf,"开灯");
					ret = msgsnd(msgid,&MSG,len_msg,0);
					if(ret < 0)
						TCP.type = LED_FAILURE;
					else
						TCP.type = LED_SUCCESS;
					send_ret = send(confd,&TCP,sizeof(tcp_t),0);
					if(send_ret < 0)
					{
						perror("send(LED)");
						//return -6;
					}
				}
				if(TCP.type == TEM_REQUEST)
				{
					bzero(&TCP,sizeof(TCP));
					strcpy(TCP.data,SHM->tep);
					TCP.type = TEM_SUCCESS;
					send_ret = send(confd,&TCP,sizeof(tcp_t),0);
					if(send_ret < 0)
					{
						perror("send(TEM)");
						//return -7;
					}
				}
			}
		}
	}
#endif	

	return 0;
}
