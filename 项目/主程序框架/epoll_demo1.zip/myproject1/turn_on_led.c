#include "myhead.h"

int main(int argc, const char *argv[])
{
	int ret,fd;
	key_t key = ftok("/home/linux/",'u');
	if(key < 0)
	{
		perror("ftok");
		return -258;
	}
	int msgid = msgget(key,0664|IPC_CREAT);
	if(msgid < 0)
	{
		perror("msgget");	
		return -198;
	}
	msg_t MSG;
	bzero(&MSG,sizeof(MSG));
	size_t len_msg = sizeof(MSG) - sizeof(long);
	while(1)
	{
		fd = open("./Maru.txt",O_WRONLY | O_CREAT | O_APPEND,0664);
		if(fd < 0)
		{
			perror("open");
			return -131;
		}
		ret = msgrcv(msgid,&MSG,len_msg,LED_REQ_MSG,0);
		if(ret < 0)
		{
			perror("msgrcv");
			return -666;
		}
		ret = write(fd,MSG.buf,strlen(MSG.buf));
		if(ret < 0)
		{
			perror("write");
			return -52;
		}

	}
	return 0;
}
