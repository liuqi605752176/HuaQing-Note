#include "myhead.h"
int main(int argc, const char *argv[])
{
	int ret,shmid,fd;
	ssize_t n;
	key_t key;
	key = ftok("/home/linux/",'u');
	if(key < 0)
	{
		perror("ftok");
		return -257;
	}
	shmid = shmget(key,100,0664|IPC_CREAT); //创建共享内存
	if(shmid < 0)
	{
		perror("shmget");
		return -405;
	}
	shm_t *SHM;
	SHM = shmat(shmid,NULL,0);    //获取映射
	if(SHM == NULL)
	{
		perror("shmat");
		return -324;
	}
	while(1)
	{
		fd = open("./INnoVation.txt",O_RDONLY);
		if(fd < 0)
		{
			perror("open");
			return 123;
		}
		lseek(fd,0,SEEK_SET);
		bzero(SHM->tep,sizeof(SHM->tep));
		n = read(fd,SHM->tep,sizeof(SHM->tep));
		if(n < 0)
		{
			perror("read");
			return 321;
		}
		else if(n == 0)
		{
			fprintf(stderr,"未读取到温度值!\n");
			return 213;
		}
		usleep(100000);  //每100ms读取一次
	}
	
	return 0;
}
