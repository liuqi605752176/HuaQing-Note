#include "17071.h"


int main(int argc, const char *argv[])
{
	
	//ftok
	//msgget
	//
	//
	//shmget
	//映射


//tcp 主要代码段

//socket 
//bind
//listen
	while(1)
	{
		//accept
		while(1)
		{
			//recv
			//三种返回值--》
				//if()  == 点灯
				//msgsend
				//send 点灯ok
				//else if == 查温度
				//send 温度
			
		}
	}


//销毁过程
	//取消映射
	//IPC_RMID


	return 0;
}
