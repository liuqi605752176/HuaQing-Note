#include "17071.h"


int main(int argc, const char *argv[])
{
	//socket
	//bind
	//connect
	while(1)
	{
		//scanf 命令
		//if    点灯  或者 查温度
		//填结构体
		//send
		//
		//
		//recv
		//判断 收到的 类型
		//点灯成功  打印成功
		//查温度  打印数值

	}
	return 0;
}
