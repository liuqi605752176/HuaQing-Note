#include "17071.h"


int main(int argc, const char *argv[])
{
	// open   读文件
	//ftok
	//shmget 打开
	

	//映射
	//
	while(1)
	{
		//也可以读文件内的数据
		//周期性写温度到共享内存里
		//假代码可以写点随机数之类的
	
	
	
	}
	//
	//取消映射


	return 0;
}
