#include "17071.h"


int main(int argc, const char *argv[])
{
	//open  文件  写


	//ftok
	//msgget  直接打开
	//
	//
	while(1)
	{
	
		//msgrecv  
		//write

	}




	return 0;
}
