#ifndef _HEAD_H_
#define _HEAD_H_


#define SIZE 512

typedef struct user{
	int type;
	char username[SIZE];
    char password[SIZE];
	char ans[SIZE];

}umsg;


//cmd
#define LED_ON '2'
#define LED_OFF '3'
#define TEMP_HUMI '4'  //��ʪ��
#define SMOKE '5' //����
#define FIRE '6' //����
#define BODY '7' //����

#define PATH "/dev/ttyUSB0" //�����豸�ļ�·��
//#define PATH "./usart.txt"

struct shmbuf
{
	short int data[2];
};

struct msgbuf
{
	long mtype;
	char mtext[1];
};


#endif// _HEAD_H_
