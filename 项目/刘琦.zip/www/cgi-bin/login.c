
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h> /* superset of previous */
#include <stdlib.h>
#include <strings.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <errno.h>
#include <sys/msg.h>
#include <time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include<string.h>
#include<time.h>
#include"cgic.h"
#include<sqlite3.h>
#include<pthread.h>
#include<semaphore.h>
#include "head.h"


int login_callback(void *flag,int f_count,char** f_valu,char** name) //login_callback
{    //查询成功,表中有此用户名,flag++
	(*(int *)flag)++;
	return 0;

}
void do_login(umsg *umsg,sqlite3 *db)
{
	char cmd[100];
	char *errmasg=NULL;
	int flag,temp,ret_sq;
	flag=temp=0;
	umsg->type=4;

	bzero(cmd,sizeof(cmd));
	sprintf(cmd,"select * from umsg where username='%s' and password='%s'",umsg->username,umsg->password);
	ret_sq=sqlite3_exec(db,cmd,login_callback,&flag,&errmasg);
	if(ret_sq != SQLITE_OK)//执行命令出错
	{
		printf("error2: %s\n",errmasg);
		sqlite3_free(errmasg);
	}

	if(flag!=temp)//表示login_callback回调成功,flag==1,temp==0,此时不相等
	{
		sprintf(umsg->ans,"login success!");//将0k拷贝到msg->data中
	    fprintf(cgiOut,"<H1>欢迎来到德玛西亚 </H1>");
	}
	else 
	{
		sprintf(umsg->ans,"username or password is error!");//登陆不成功
		printf(" %s 此帐号玩家尚未注册\n",umsg->username);
	}


	return ;
}

int cgiMain()
{
	cgiHeaderContentType("text/html");

	umsg umsg;    
	sqlite3* db; 
	int ret_sq;   
	char cmd[100];

	ret_sq=sqlite3_open("./user.db",&db);
	if(ret_sq != SQLITE_OK)
	{
		printf("fail to open db\n");
		return -1;
	}


	fprintf(cgiOut,"<html><head><title>登录</title><meta charset=""utf-8""></head>");
	fprintf(cgiOut,"<body background=""/images/timg.jpg"">");
	fprintf(cgiOut,"<div align=""center"">");
	fprintf(cgiOut,"<br><br><br><br><br><br><br><br>");
//	fprintf(cgiOut,"<table width=""1024"" height=""767"" border=""0"" background=""/images/timg.jpg"">");
	bzero(&umsg,sizeof(umsg));
	cgiFormString("user",umsg.username,sizeof(umsg.username));
	cgiFormString("password",umsg.password,sizeof(umsg.password));
     
	do_login(&umsg,db);


	fprintf(cgiOut,"<H3>请选择技能选项 </H3>");
	if(strcmp(umsg.ans,"login success!")==0)
	{
	fprintf(cgiOut,"<form action=""/choose.html"" method=""get""><input type=""submit"" value=""技能页面""></form>");
	}

	fprintf(cgiOut,"</div></body></html>");
	return 0;
}
