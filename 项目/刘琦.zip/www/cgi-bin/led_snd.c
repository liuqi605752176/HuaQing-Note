#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>

#include "cgic.h"
#include "head.h"

int cgiMain()
{
	key_t key;
	int msgid;
	char buf[2];

	struct msgbuf msg_buf;

	char cmd;

	cgiFormString("led", buf, sizeof(buf));

	cgiHeaderContentType("text/html\n\n"); 
	fprintf(cgiOut, "<HTML><HEAD>\n"); 
	fprintf(cgiOut, "<TITLE>LED CGI</TITLE></HEAD>\n"); 
	fprintf(cgiOut, "<BODY>"); 

	cmd = buf[0];
	memset(&msg_buf, 0, sizeof(msg_buf));

	//	bzero (msg_buf.mtext, sizeof (msg_buf.mtext));

	if (cmd == LED_ON)
	{
		msg_buf.mtext[0] = '2';

	}
	else if(cmd == LED_OFF)
	{
		msg_buf.mtext[0] = '3';
	}


	key = ftok("/",'c');

	if(-1 == key)
	{
		fprintf(cgiOut,"ftok error!");
		return -1;
	}
#if 0
	msgid = msgget(key,IPC_CREAT|IPC_EXCL|0666);
	if(msgid == -1)
	{
		if(errno == EEXIST)
		{
			msgid = msgget(key,0666);

		}else
		{
			//			perror("msgget");
			fprintf(cgiOut,"msgget error!");
			return -1;
		}
	}
#endif
	msgid = msgget(key,0666);



	msg_buf.mtype = 200;
	//fgets(msg_buf.mtext,sizeof(msg_buf.mtext),stdin);

	if(-1 == msgsnd(msgid,&msg_buf,sizeof(msg_buf.mtext),0))
	{
		//		perror("msgsnd");
		fprintf(cgiOut,"msgsnd error!");
		return -1;
	}

	fprintf(cgiOut, "<H2>send sucess</H2>");
	fprintf(cgiOut, "<H2></H2>");
	fprintf(cgiOut, "<meta http-equiv=\"refresh\"content=\"4;url=../led.html\">");
	fprintf(cgiOut, "</BODY>\n"); 
	fprintf(cgiOut, "</HTML>\n"); 	
	return 0;
}
