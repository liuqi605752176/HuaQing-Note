#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <errno.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<termios.h>


#include "cgic.h"
#include "msgq.h"
#if 1
void serial_init(int fd)
{
	struct termios options;//termios数族提供一个常规的终端接口，用于控制非同步通信端口。
	tcgetattr(fd, &options);//取得当前串口的属性，并付给collect_fd这个设备
	options.c_cflag |= (CLOCAL | CREAD);//clocal表示å略modem控制线，cread表示打开接收者
	options.c_cflag &= ~CSIZE;//清空原有字符长度（csize表示原有字符长度掩码）
	options.c_cflag &= ~CRTSCTS;//启用RTS/CTS（硬件）流控制
	options.c_cflag |= CS8;//è¾置字符长度掩码
	options.c_cflag &= ~CSTOPB;//è¾置停止位äº1个（cstopb表示设置两个停止位）
	options.c_iflag |= IGNPAR;//忽略帧错误和奇偶校验错
	options.c_iflag &= ~(BRKINT | INPCK | ISTRIP | ICRNL | IXON);

	options.c_cc[VMIN] = 0;//字符长度

	options.c_oflag = 0;//设置输出模式标志
	options.c_lflag = 0;//è¾置本地模入标志

	cfsetispeed(&options,B9600);//设置输入波特率
	cfsetospeed(&options,B9600);//设置输出波特率

	tcsetattr(fd, TCSANOW,&options);//把上面设置号的属性赋值给collect_fd这个设备，tcsanow表示马上生效
	printf("init gprs over...over\n");
	return ;
}
#endif
int main(int argc, const char *argv[])
{
	key_t key;
	int msgid;
	msg_s msg_buf;

	int dev_uart_fd;

	key = ftok("/dev",'i');
	if(key < 0)
	{
		perror("ftok");
		return -1;
	}
	msgid = msgget(key,IPC_CREAT|IPC_EXCL|0666);
	if(msgid == -1)
	{
		if(errno == EEXIST)
		{
			msgid = msgget(key,0666);
			if(msgid == -1)
			{
				printf("error\n");
				return -1;
			}
		}else
		{
			perror("msgget");
			return -1;
		}
	}
#if 1
	if ((dev_uart_fd = open ("/dev/ttyUSB0", O_RDWR)) < 0)
	{
		perror ("open ttyUSB");
		return -1;
	}
#endif
	unsigned int temp=0;
//int abcdefg = 10;
	serial_init (dev_uart_fd);
	while(1 )
	{
	//	printf("hahahahah\n");
#if 0
		tt = 2;
		printf("tt =2\n");
		write(dev_uart_fd,&tt,1);
		sleep(1);
		tt = 1;
		printf("tt =1\n");
		write(dev_uart_fd,&tt,1);
		sleep(1);

#endif
		//temp =0 ;
		//printf("***************** \n");
		if(-1 == msgrcv(msgid,&msg_buf,MSGSIZE,100,0))
		{
			perror("msgrcv");
			return -1;
		}
		if(0 == strncmp("quit",msg_buf.text,4))
		{
			break;
		}
#if 1
		if(1 == msg_buf.text[0])
		{
			temp = 1;
		}
		if(2 == msg_buf.text[0])
		{
			temp = 2;
		}
#endif 
	//	printf("temp:%d\n",temp);
	//	fputs(msg_buf.text,stdout);
//printf("abcdefg = %c\n",msg_buf.text[0]);
//	printf("temp:%d\n",temp);
		write(dev_uart_fd,&temp,4);

	//	printf("success \n");

	}
 


if(-1 == msgctl(msgid,IPC_RMID,NULL))
{
	perror("msgctl");
	return -1;
}

	return 0;
}
