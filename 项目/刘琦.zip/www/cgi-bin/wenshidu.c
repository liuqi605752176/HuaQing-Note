#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/shm.h>
#include "cgic.h"
#include "head.h"

int cgiMain()
{
	key_t key;
	int msgid;
	char buf[2];
	struct msgbuf msg_buf;

	char cmd;

	cgiFormString("wenshidu", buf, sizeof(buf));
	
	cgiHeaderContentType("text/html;charset=utf-8\n\n"); 
	fprintf(cgiOut, "<HTML><HEAD>\n"); 
	fprintf(cgiOut, "<TITLE>LED CGI</TITLE></HEAD>\n"); 
	fprintf(cgiOut, "<BODY>"); 

	cmd = buf[0];
	memset(&msg_buf, 0, sizeof(msg_buf));

	bzero (msg_buf.mtext, sizeof (msg_buf.mtext));

	msg_buf.mtext[0] = TEMP_HUMI;
	

	//printf(" wenshidu cmd = %c\n",cmd);

	key = ftok("/",'c');
	if(-1 == key)
	{
	fprintf(cgiOut,"ftok error!");
		return -1;
	}
#if 0	
	msgid = msgget(key,IPC_CREAT|IPC_EXCL|0666);
	
	if(msgid == -1)
	{
		if(errno == EEXIST)
		{
			msgid = msgget(key,0666);
		}else
		{
//			perror("msgget");
		fprintf(cgiOut,"msgget error!");
			return 2;
		}
	}
#endif
	msgid = msgget(key,0666);
	int shmid;
	struct shmbuf *shm;

	shmid = shmget(key,sizeof(struct shmbuf),0666);
	shm = shmat(shmid,NULL,0);
	if(shm == (void *)-1)
	{
		return -1;
	}

	msg_buf.mtype = 200;

	//fgets(msg_buf.mtext,sizeof(msg_buf.mtext),stdin);

	if(-1 == msgsnd(msgid,&msg_buf,sizeof(msg_buf.mtext),0))
	{
//		perror("msgsnd");
		fprintf(cgiOut,"msgsnd error!");
		return 3;
	}
	
	fprintf(cgiOut,"cmd = %c\n",cmd);
	fprintf(cgiOut,"msg_buf.mtype = %ld\n",msg_buf.mtype);
	fprintf(cgiOut,"msg_buf.mtext[0] = %c\n",msg_buf.mtext[0]);

	fprintf(cgiOut, "<H2>send sucess</H2>");
	fprintf(cgiOut, "<H2></H2>");
	
	fprintf(cgiOut, "湿度:%d\n", shm->data[0]);
	fprintf(cgiOut, "温度:%d\n", shm->data[1]);
	
	fprintf(cgiOut, "<meta http-equiv=\"refresh\"content=\"4;url=../env.html\">");
	fprintf(cgiOut, "</BODY>\n"); 
	fprintf(cgiOut, "</HTML>\n"); 	
	return 0;
}
