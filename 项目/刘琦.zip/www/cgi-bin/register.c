
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h> /* superset of previous */
#include <stdlib.h>
#include <strings.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <errno.h>
#include <sys/msg.h>
#include <time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include<string.h>
#include<time.h>
#include"cgic.h"
#include<sqlite3.h>
#include<pthread.h>
#include<semaphore.h>
#include "head.h"


int register_callback(void *flag,int f_count,char** f_valu,char** name)  {
	(*(int *)flag)++;
	return 0;
}

void do_register(umsg *umsg,sqlite3 *db)
{
	int ret_sq;
	char cmd[100];
	char* errmasg=NULL;
	int temp,flag;
	temp=flag=0;

	bzero(cmd,sizeof(cmd));
	sprintf(cmd,"select * from umsg where username='%s'",umsg->username);
	ret_sq=sqlite3_exec(db,cmd,register_callback,&flag,&errmasg);
	if(ret_sq != SQLITE_OK)
	{
		printf("error: %s\n",errmasg);
		sqlite3_free(errmasg);
	}

	if(flag==temp)	{
		bzero(cmd,sizeof(cmd));
		sprintf(cmd,"insert into umsg values('%s','%s')",umsg->username,umsg->password);	
		ret_sq=sqlite3_exec(db,cmd,NULL,NULL,&errmasg);
		if(ret_sq != SQLITE_OK)
		{
			printf("error: %s\n",errmasg);
			sqlite3_free(errmasg);
		}

		sprintf(umsg->ans,"user %s register success!",umsg->username);
		fprintf(cgiOut,"<H1>恭喜你成功注册玩家帐号</H1>");

	}
	else 
	{
		sprintf(umsg->ans,"user is existed,fail to register !");//表示用户名已存在,或用户名重复
	}  
	return ;

}


int cgiMain()
{
	cgiHeaderContentType("text/html");

	umsg umsg;
	sqlite3* db;
	int ret_sq;
	char cmd[100];


	ret_sq=sqlite3_open("./user.db",&db);
	if(ret_sq != SQLITE_OK)
	{
		printf("fail to open db\n");
		return -1;
	}

	bzero(cmd,sizeof(cmd));
	sprintf(cmd,"create table umsg (username char(50),password char(50))");
	sqlite3_exec(db,cmd,NULL,NULL,NULL);


	bzero(&umsg,sizeof(umsg));
	cgiFormString("user",umsg.username,sizeof(umsg.username));
	cgiFormString("password",umsg.password,sizeof(umsg.password));


	fprintf(cgiOut,"<html><head><title>注册</title><meta charset=""utf-8""></head><body>");

	do_register(&umsg,db);


	fprintf(cgiOut,"<form action=""/index1.html"" method=""get""><input type=""submit"" value=""返回""></form>");
	fprintf(cgiOut,"</body></html>");

	return 0;
}
