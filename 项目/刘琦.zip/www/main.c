#include <stdio.h>
#include "head.h"
#include <pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/msg.h>
#include <errno.h>
#include <semaphore.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <strings.h>
       #include <arpa/inet.h>

char cmd;

sem_t flag1,flag2,flag3;

short int data[2];

int shmid;
struct shmbuf *shm;

int msgid;
struct msgbuf msg;

int set_opt(int fd,int nSpeed, int nBits, char nEvent, int nStop);//串口初始化

//线程1
void *thread1(void *arg)
{
	while(1)
	{
		sem_wait(&flag1);

		//接收消息队列
		msgrcv(msgid, &msg, sizeof(msg.mtext), 200, 0);
		cmd = msg.mtext[0];	
		printf("cmd = %c\n", cmd);

		sem_post(&flag2);
	}
}

//线程2
void *thread2(void *arg)
{
	int i;
	while(1)
	{
		sem_wait(&flag3);

		for(i=0; i<2; i++)
		{
			//发送共享内存
			shm->data[i] =htons(data[i]);
		}

		sem_post(&flag1);
	}

}

//线程3
void *thread3(void *arg)
{
	int fd = *(int *)arg;
	char i;
	while(1)
	{
		sem_wait(&flag2);

		//向下位机发送cmd
		write(fd, &cmd, 1);

		//接收下位机data
		for(i=0; i<2; i++)
		{
			read(fd, &data[i], 1);
		}
		if(cmd == SMOKE || cmd == FIRE)
		{
			data[0] |= (data[1] << 8);
		}

		sem_post(&flag3);
	}
}

int main(int argc, const char *argv[])
{
	int fd;

	pthread_t thread1_id;
	pthread_t thread2_id;
	pthread_t thread3_id;

	//获取键值
	key_t key_value = ftok("/", 'i');

	//共享内存
	shmid = shmget(key_value,sizeof(struct shmbuf), IPC_CREAT | IPC_EXCL | 0666);
	if(shmid < 0)
	{
		if(errno == EEXIST)
		{
			shmid = shmget(key_value,sizeof(struct shmbuf), 0666);
		}
		else
		{
			return -1;
		}
	}

	//映射
	shm = shmat(shmid, NULL, 0);
	if(shm == (void *)-1)
	{
		return -1;
	}

	//消息队列
	msgid = msgget(key_value, IPC_CREAT | IPC_EXCL | 0666);
	if(msgid < 0)
	{
		if(errno == EEXIST)
		{
			msgid = msgget(key_value, 0666);
		}
		else
		{
			return -1;
		}
	}

	//初始化信号量
	sem_init(&flag1,0,1);
	sem_init(&flag2,0,0);
	sem_init(&flag3,0,0);

	//打开串口
	fd = open(PATH, O_RDWR);

	//初始化串口
	set_opt(fd, 115200, 8, 'N', 1); 

	//创建线程
	pthread_create(&thread1_id, NULL, thread1, NULL);
	pthread_create(&thread2_id, NULL, thread2, NULL);
	pthread_create(&thread3_id, NULL, thread3, &fd);

	//阻塞进程，直到线程退出
	pthread_join(thread1_id, NULL);
	pthread_join(thread2_id, NULL);
	pthread_join(thread3_id, NULL);

	//关闭文件描述符
	close(fd);

	//销毁信号量
	sem_destroy(&flag1);
	sem_destroy(&flag2);
	sem_destroy(&flag3);

	//删除消息队列
	msgctl(msgid, IPC_RMID, NULL);

	//取消映射
	shmdt(shm);
	//删除共享内存
	shmctl(shmid, IPC_RMID, NULL);

	return 0;
}

int set_opt(int fd,int nSpeed, int nBits, char nEvent, int nStop)
{
	struct termios newtio,oldtio;
	if  ( tcgetattr( fd,&oldtio)  !=  0) { 
		perror("SetupSerial 1");
		return -1;
	}
	bzero( &newtio, sizeof( newtio ) );
	newtio.c_cflag  |=  CLOCAL | CREAD;
	newtio.c_cflag &= ~CSIZE;

	switch( nBits )
	{
	case 7:
		newtio.c_cflag |= CS7;
		break;
	case 8:
		newtio.c_cflag |= CS8;
		break;
	}

	switch( nEvent )
	{
	case 'O':
		newtio.c_cflag |= PARENB;
		newtio.c_cflag |= PARODD;
		newtio.c_iflag |= (INPCK | ISTRIP);
		break;
	case 'E': 
		newtio.c_iflag |= (INPCK | ISTRIP);
		newtio.c_cflag |= PARENB;
		newtio.c_cflag &= ~PARODD;
		break;
	case 'N':  
		newtio.c_cflag &= ~PARENB;
		break;
	}

	switch( nSpeed )
	{
	case 2400:
		cfsetispeed(&newtio, B2400);
		cfsetospeed(&newtio, B2400);
		break;
	case 4800:
		cfsetispeed(&newtio, B4800);
		cfsetospeed(&newtio, B4800);
		break;
	case 9600:
		cfsetispeed(&newtio, B9600);
		cfsetospeed(&newtio, B9600);
		break;
	case 115200:
		cfsetispeed(&newtio, B115200);
		cfsetospeed(&newtio, B115200);
		break;
	case 460800:
		cfsetispeed(&newtio, B460800);
		cfsetospeed(&newtio, B460800);
		break;
	default:
		cfsetispeed(&newtio, B9600);
		cfsetospeed(&newtio, B9600);
		break;
	}
	if( nStop == 1 )
		newtio.c_cflag &=  ~CSTOPB;
	else if ( nStop == 2 )
		newtio.c_cflag |=  CSTOPB;
	newtio.c_cc[VTIME]  = 0;
	newtio.c_cc[VMIN] = 0;
	tcflush(fd,TCIFLUSH);
	if((tcsetattr(fd,TCSANOW,&newtio))!=0)
	{
		perror("com set error");
		return -1;
	}
	//	printf("set done!\n\r");
	return 0;
}
